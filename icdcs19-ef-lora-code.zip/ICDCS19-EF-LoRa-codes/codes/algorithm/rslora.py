# -*- coding: utf-8 -*-
import math
import random

nodes = 3000#number of devices
gateways = 9#number of gateways
count = 0
tp = [2,4,6,8,10,12,14]#transmission power
ch = range(8)#channels
alloc_0 = [99]*nodes#original allocation
distance,temp1 = [],[]

f1 = open("distance-9-3000.txt")  # 返回一个文件对象
line = f1.readline()  # 调用文件的 readline()方法

#extract distances between eds and gws
while line:
    if count < gateways:
        temp1.append(line[line.index(',')+1:-1])
        count += 1
    elif count == gateways:
        distance.append(temp1)
        temp1 = []
        temp1.append(line[line.index(',')+1:-1])
        count = 1
    line = f1.readline()
distance.append(temp1)

near = []
ns = []
nn = []
for ed in distance:
    near.append(min(ed))

p = [0.4497991967871486, 0.2570281124497992, 0.14457831325301204, 0.08032128514056225, 0.04417670682730924, 0.024096385542168676]
c = [0.125]*8
for i in p:
   ns.append(int(round(i * nodes)))
print ns
for j in near:
    nn.append(float(j))
sf = [5,4,3,2,1,0]
for i in range(ns[0]):
    alloc_0[nn.index(min(nn))] = 5
    nn[nn.index(min(nn))] = 999999
for i in range(ns[1]):
    alloc_0[nn.index(min(nn))] = 4
    nn[nn.index(min(nn))] = 999999
for i in range(ns[2]):
    alloc_0[nn.index(min(nn))] = 3
    nn[nn.index(min(nn))] = 999999
for i in range(ns[3]):
    alloc_0[nn.index(min(nn))] = 2
    nn[nn.index(min(nn))] = 999999
for i in range(ns[4]):
    alloc_0[nn.index(min(nn))] = 1
    nn[nn.index(min(nn))] = 999999
for i in range(ns[5]):
    alloc_0[nn.index(min(nn))] = 0
    nn[nn.index(min(nn))] = 999999


f = open("rs-9-3000.txt",'w')
f.writelines(str(alloc_0))
f.close()
print alloc_0
print near
print len(near)

# k = 0
# for i in ns:
#     for j in range(i):
#         if len(near):
#             alloc_0[near.index(min(near))] = sf[k]
#             #near[near.index(min(near))] = 999999
#             del near[near.index(min(near))]
#     k+=1
# print alloc_0

# nums = [1,8,2,23,7,-4,18,23,24,37,2]
# temp=[]
# Inf = 99999
# for j in ns:
#     for i in range(j):
#       temp.append(near.index(min(near)))
#       near[near.index(min(near))]=Inf
#       alloc_0[near.index(min(near))
#     temp.sort()
#     alloc_0.append(temp)
# print(alloc_0)