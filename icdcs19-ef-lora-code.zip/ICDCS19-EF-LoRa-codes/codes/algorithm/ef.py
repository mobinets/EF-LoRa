# -*- coding: utf-8 -*-
import math
import random
import time
nodes = 3000
gateways = 5
count, count1 = 0, 0
#now tp is identical
tp = [2,4,6,8,10,12,14]#transmission power
ch = range(8)#channels
c = 3*pow(10,8)#light speed
f = 9.15*pow(10,8)# frequency
R = 5000#radius
beta = 2#attenuation
delta = 1#convergence
xx = -99999999999
density = nodes/math.pi/R/R
SF = [7,8,9,10,11,12]




alloc_0 = []#original allocation
for i in range(nodes):
    alloc_0.append(random.randint(7,12))
#alloc_0 = [11, 8, 11, 7, 8, 12, 7, 10, 7, 11]
print alloc_0
distance, temp1, temp2, temp3,temp4 = [], [], [], [],[]
pdr,pdr2 = [],[]
snr_th = [-6,-9,-12,-15,-17.5,-20]
sensitivity = [-123,-126,-129,-132,-134.5,-137]
spreading = [7,8,9,10,11,12]


#f_test = open("test.txt")
#line = f_test.readline()
f1 = open("distance-5-3000.txt")  # 返回一个文件对象
line = f1.readline()  # 调用文件的 readline()方法

#extract distances between eds and gws
while line:
    if count < gateways:
        temp1.append(line[line.index(',')+1:-1])
        count += 1
    elif count == gateways:
        distance.append(temp1)
        temp1 = []
        temp1.append(line[line.index(',')+1:-1])
        count = 1
    line = f1.readline()
distance.append(temp1)
#print(distance)


def min_ee(list):
    # number of nodes with sfs
    ns_def = [0, 0, 0, 0, 0, 0]
    for x_def in list:
        if x_def == 7:
            ns_def[0] += 1
        elif x_def == 8:
            ns_def[1] += 1
        elif x_def == 9:
            ns_def[2] += 1
        elif x_def == 10:
            ns_def[3] += 1
        elif x_def == 11:
            ns_def[4] += 1
        elif x_def == 12:
            ns_def[5] += 1
    # print ns
        # def calc_pdr(distance[[]]):
    cc_def = 0
    temp2_def, pdr_def, pdr2 = [],[],[]
    for e in distance:
        sf_def = list[cc_def]
        for g in e:
            t_def = (20.25 + (8 * 25 - 4 * sf_def + 44) / (4 * sf_def)) * pow(2, sf_def) / 125000
            h_def = 1 - ns_def[sf_def - 7] * t_def / 10 * math.exp(-2 * ns_def[sf_def - 7] * t_def / 10)
            a_def = pow((c/4/math.pi/f/float(g))*1000,2)
            #print a_def
            #pp = math.pi*math.pi/2*density*ns_def[sf_def - 7] /nodes*pow(-snr_th[sf_def-7]*h_def/a_def,0.5)#-sensitivity[sf-7]/tp/pow(c/4/math.pi/f/float(g), 2)
            pp = math.exp( (snr_th[sf_def - 7]) * h_def / tp * pow(4 * math.pi * f * float(g) / 1000 / c, 2) * 2 * pow(math.pi, 2) * density *ns_def[sf_def - 7] / nodes / math.sin( math.pi / 2) / 2)  # -sensitivity[sf-7]/tp/pow(c/4/math.pi/f/float(g), 2))
            # pp = math.exp((snr_th[sf - 7]) * h / tp * density * ns[sf - 7] / nodes * pow(math.pi,6) *144*72)
            #print pp
            temp2_def.append(pp)
        pdr_def.append(temp2_def)
        temp2_def = []
        cc_def += 1

    # calculate energy (mW)
    energy_def = []
    for i in range(nodes):
        sf_def = list[i]
        t = (20.25 + (8 * 25 - 4 * sf_def + 44) / (4 * sf_def)) * pow(2, sf_def) / 125000
        energy_def.append(250 + 9.1 * list[i] * t)
    #print energy_def

    # calculate new ee
    prr_def, ee_0_def = [], []
    per_def = 1
    r_def = 0

    for ed in pdr_def:
        for p in ed:
            per_def = per_def * (1 - p)
        r_def = 1 - per_def
        per_def = 1
        prr_def.append(r_def)
   # print prr_def
    for i_def in range(nodes):
        ee_0_def.append(200 * prr_def[i_def] / energy_def[i_def])
    min_ee_def = min(ee_0_def)
    return min_ee_def

alloc_new = []
for a in alloc_0:
    alloc_new.append(a)

delta = 99999
tempnew = 0
start = time.clock()


#while delta > 0.1:
count = 0
for i in alloc_0:
    tempx = -99999
    tempsf = 0
    for sf in SF:
        alloc_new[count] = sf
        minEE = min_ee(alloc_new)
        if minEE > tempx:
            tempx = minEE
            tempsf = sf
    alloc_new[count] = tempsf
    count += 1
delta = tempx-tempnew
tempnew = tempx
print delta
print tempx

print alloc_new

end = time.clock()

print end-start