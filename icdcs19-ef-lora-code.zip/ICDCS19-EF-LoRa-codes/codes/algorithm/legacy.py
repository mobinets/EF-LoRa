# -*- coding: utf-8 -*-
import math
import random
import time
import numpy
from collections import Counter
# distance_gw1 = [9999.5, 249.8, 441.4, 99999.2, 9999.8, 999.7, 999.8, 234.2, 301.4, 354.5,     999, 331.8, 397.1, 9999.5, 999, 274, 280, 402.7, 399, 483.3,      9999.3, 999.6, 213.2, 433.2, 999.2, 9999, 210, 999.4, 474.9, 262.5]
# distance_gw2 = [9999.5, 220, 445.4, 9999, 9999.1, 999.4, 999, 226.2, 282, 330,    999.7, 330.6, 386.9, 999.1, 9999.7, 285.5, 228.4, 369.4, 356, 445.3,        999, 9999.8, 174, 415.6, 999, 9999.7, 999, 170, 448, 252.8]
# distance_gw3 = [253, 410.8, 620, 181.4, 163.9, 9999.7, 999.7, 9999, 999.8, 999.2,       295.6, 515.1, 569.3, 999.2, 999.2, 9999.4, 9999.7, 204.7, 203.3, 287.3,      227.4, 275.6, 363.7, 599, 999.3, 999.7, 177.9, 9999.1, 280.5, 9999.7]
# alloc = [0,0,0,7]
# all = 0
# for i in range(7,13):
#     all += i/math.pow(2,i)
# list = []
# for i in range(7,13):
#     list.append(i/math.pow(2,i)/all*30)
# # print list
# # print str(distance_gw1.index(min(distance_gw1)))+":"+str(min(distance_gw1))
# # print str(distance_gw2.index(min(distance_gw2)))+":"+str(min(distance_gw2))
# # print str(distance_gw3.index(min(distance_gw3)))+":"+str(min(distance_gw3))
# distance = [117.5, 249.8, 441.4, 123.2, 69.8, 157.7, 195.8, 234.2, 301.4, 354.5,     135, 331.8, 397.1, 121.5, 170, 274, 280, 402.7, 399, 483.3,      42.3, 170.6, 213.2, 433.2, 202.2, 134, 210, 208.4, 474.9, 262.5,     92.5, 220, 445.4, 22, 78.1, 138.4, 108, 226.2, 282, 330,    127.7, 330.6, 386.9, 108.1, 62.7, 285.5, 228.4, 369.4, 356, 445.3,        139, 86.8, 174, 415.6, 99, 65.7, 106, 170, 448, 252.8,     253, 410.8, 620, 181.4, 163.9, 61.7, 121.7, 38, 102.8, 158.2,       295.6, 515.1, 569.3, 102.2, 145.2, 101.4, 84.7, 204.7, 203.3, 287.3,      227.4, 275.6, 363.7, 599, 146.3, 122.7, 177.9, 37.1, 280.5, 63.7]
# for i in range(90):
#     print str(distance.index(min(distance)))+":"+str(min(distance))
#     distance[distance.index(min(distance))] = 999



# 20:42.3
# 3:22
# 27:37.1
# 4:69.8
# 14:62.7
# 7:38
# 0:117.5
# 25:65.7
# 5:61.7
# 13:121.5
# 4:78.1
# 29:63.7
# 3:123.2
# 21:86.8
# 16:84.7
# 25:134
# 0:92.5
# 15:101.4
# 10:135
# 24:99
# 13:102.2
# 5:157.7
# 26:106
# 8:102.8
# 14:170
# 6:108
# 6:121.7
# 21:170.6
# 13:108.1
# 25:122.7
# 6:195.8
# 10:127.7
# 14:145.2
# 24:202.2
# 5:138.4
# 24:146.3
# 27:208.4
# 20:139
# 9:158.2
nodes=30
c = 3*pow(10,8)#light speed
f = 9.025*pow(10,8)# frequency
alpha = 0.1
snr_th = [-6,-9,-12,-15,-17.5,-20]

distance_gw1 = [117.5, 249.8, 441.4, 123.2, 69.8, 157.7, 195.8, 234.2, 301.4, 354.5,     135, 331.8, 397.1, 121.5, 170, 274, 280, 402.7, 399, 483.3,      42.3, 170.6, 213.2, 433.2, 202.2, 134, 210, 208.4, 474.9, 262.5]
distance_gw2 = [92.5, 220, 445.4, 22, 78.1, 138.4, 108, 226.2, 282, 330,    127.7, 330.6, 386.9, 108.1, 62.7, 285.5, 228.4, 369.4, 356, 445.3,        139, 86.8, 174, 415.6, 99, 65.7, 106, 170, 448, 252.8]
distance_gw3 = [253, 410.8, 620, 181.4, 163.9, 61.7, 121.7, 38, 102.8, 158.2,       295.6, 515.1, 569.3, 102.2, 145.2, 101.4, 84.7, 204.7, 203.3, 287.3,      227.4, 275.6, 363.7, 599, 146.3, 122.7, 177.9, 37.1, 280.5, 63.7]
distance_gw4 = [81.8, 173.7, 401.7, 97.4, 146.3, 205.2, 160.8, 296.4, 345.7, 388.1,    123.9, 295.2, 346.1, 187.3, 139.3, 372.8, 302.8, 428.9, 416.9, 499.6,      167.8, 41.1, 120, 363.4, 132.6, 147.3, 114.1, 262.2, 480, 321.7]

a_gw1, a_gw2, a_gw3 = [],[],[]
count1,count2,count3 = 0,0,0
for i in distance_gw1:
    if count1 in [0,2,4,5,6,11,12,13,14,20,21,23,25]:
        a_gw1.append(c/4/math.pi/f/math.pow((distance_gw1[count1]/1000.0), 2.7))
    else:
        a_gw1.append(c/4/math.pi/f/math.pow((distance_gw1[count1]/1000.0), 4))
    count1+=1

for i in distance_gw2:
    if count2 in [3,4,5,6,7,8,9,13,14,16,17,18,19,25,27,28,29]:
        a_gw2.append(c/4/math.pi/f/math.pow((distance_gw2[count2]/1000.0), 2.7))
    else:
        a_gw2.append(c/4/math.pi/f/math.pow((distance_gw2[count2]/1000.0), 4))
    count2+=1

for i in distance_gw3:
    if count3 in [3,4,5,6,7,8,9,13,14,15,16,17,18,19,24,25,26,27,29]:
        a_gw3.append(c/4/math.pi/f/math.pow((distance_gw3[count3]/1000.0), 2.7))
    else:
        a_gw3.append(c/4/math.pi/f/math.pow((distance_gw3[count3]/1000.0), 4))
    count3+=1
###3gw-30ed
spreading = [8,8,12,8,8,8,8,8,8,8,8,8,8,8,8,8,8,10,10,10,8,8,8,10,8,8,8,8,10,8]

###1gw-10ed
#spreading = [8,8,12,8,8,8,8,8,8,8]
###1gw-20ed
#spreading = [8,8,12,8,8,8,8,8,8,8,8,10,10,8,8,10,8,10,10,10]
####1gw-30ed
#spreading = [8,8,12,8,8,8,8,8,8,8,8,10,10,8,8,10,8,10,10,10,8,8,8,10,8,8,8,8,12,10]
####2gw-30ed
#spreading = [8,8,12,8,8,8,8,8,8,8,   8,10,10,8,8,8,8,8,8,10,   8,8,8,10,8,8,8,8,10,8]
###3gw-30ed
#spreading = [8,8,12,8,8,8,8,8,8,8,   8,8,8,8,8,8,8,10,10,10,   8,8,8,10,8,8,8,8,10,8]
###4gw-30ed
spreading = [8,8,10,8,8,8,8,8,8,8,   8,8,8,8,8,8,8,10,10,10,    8,8,8,10,8,8,8,8,10,8]


sf = [8,10,12]

tp = [2,9,16]
tp_0 = []#original allocation
for i in range(nodes):
    tp_0.append(tp[random.randint(0,2)])
print tp_0
pdr_gw1, pdr_gw2, pdr_gw3 = [], [], []
sum1_7, sum2_7, sum3_7 = 0, 0, 0
sum1_8, sum2_8, sum3_8 = 0, 0, 0
sum1_9, sum2_9, sum3_9 = 0, 0, 0
sum1_10, sum2_10, sum3_10 = 0, 0, 0
sum1_11, sum2_11, sum3_11 = 0, 0, 0
sum1_12, sum2_12, sum3_12 = 0, 0, 0
count_tp = 0


for i in range(nodes):
    if spreading[i] == 7:
        sum1_7 += tp_0[i] * a_gw1[i] * numpy.random.exponential(1.0)
        sum2_7 += tp_0[i] * a_gw2[i] * numpy.random.exponential(1.0)
        sum3_7 += tp_0[i] * a_gw3[i] * numpy.random.exponential(1.0)
    elif spreading[i] == 8:
        sum1_8 += tp_0[i] * a_gw1[i] * numpy.random.exponential(1.0)*(1-spreading.count(8)*alpha*math.exp(-spreading.count(8))*alpha)
        sum2_8 += tp_0[i] * a_gw2[i] * numpy.random.exponential(1.0)*(1-spreading.count(8)*alpha*math.exp(-spreading.count(8))*alpha)
        sum3_8 += tp_0[i] * a_gw3[i] * numpy.random.exponential(1.0)*(1-spreading.count(8)*alpha*math.exp(-spreading.count(8))*alpha)
    elif spreading[i] == 9:
        sum1_9 += tp_0[i] * a_gw1[i] * numpy.random.exponential(1.0)
        sum2_9 += tp_0[i] * a_gw2[i] * numpy.random.exponential(1.0)
        sum3_9 += tp_0[i] * a_gw3[i] * numpy.random.exponential(1.0)
    elif spreading[i] == 10:
        sum1_10 += tp_0[i] * a_gw1[i] * numpy.random.exponential(1.0)*(1-spreading.count(10)*alpha*math.exp(-spreading.count(10))*alpha)
        sum2_10 += tp_0[i] * a_gw2[i] * numpy.random.exponential(1.0)*(1-spreading.count(10)*alpha*math.exp(-spreading.count(10))*alpha)
        sum3_10 += tp_0[i] * a_gw3[i] * numpy.random.exponential(1.0)*(1-spreading.count(10)*alpha*math.exp(-spreading.count(10))*alpha)
    elif spreading[i] == 11:
        sum1_11 += tp_0[i] * a_gw1[i] * numpy.random.exponential(1.0)
        sum2_11 += tp_0[i] * a_gw2[i] * numpy.random.exponential(1.0)
        sum3_11 += tp_0[i] * a_gw3[i] * numpy.random.exponential(1.0)
    elif spreading[i] == 12:
        sum1_12 += tp_0[i] * a_gw1[i] * numpy.random.exponential(1.0)*(1-spreading.count(12)*alpha*math.exp(-spreading.count(12))*alpha)
        sum2_12 += tp_0[i] * a_gw2[i] * numpy.random.exponential(1.0)*(1-spreading.count(12)*alpha*math.exp(-spreading.count(12))*alpha)
        sum3_12 += tp_0[i] * a_gw3[i] * numpy.random.exponential(1.0)*(1-spreading.count(12)*alpha*math.exp(-spreading.count(12))*alpha)
for i in range(nodes):
        if spreading[i] == 7:
            pdr_gw1.append(math.exp((snr_th[spreading[i]-7])*(sum1_7)/tp_0[i]/a_gw1[i]))
            pdr_gw2.append(math.exp((snr_th[spreading[i] - 7]) * (
                        sum2_7) / tp_0[i]/a_gw2[i]))
            pdr_gw3.append(math.exp((snr_th[spreading[i] - 7]) * (
                        sum3_7) / tp_0[i]/a_gw3[i]))
        elif spreading[i] == 8:
            pdr_gw1.append(math.exp(
                (snr_th[spreading[i] - 7]) * (sum1_8 ) / tp_0[i]/
                           a_gw1[i]))
            pdr_gw2.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum2_8 ) / tp_0[i] / a_gw2[i]))
            pdr_gw3.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum3_8 ) / tp_0[i] / a_gw3[i]))
        elif spreading[i] == 9:
            pdr_gw1.append(math.exp(
                (snr_th[spreading[i] - 7]) * (sum1_9 ) / tp_0[i]/
                           a_gw1[i]))
            pdr_gw2.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum2_9) / tp_0[i] / a_gw2[i]))
            pdr_gw3.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum3_9) / tp_0[i] / a_gw3[i]))
        elif spreading[i] == 9:
            pdr_gw1.append(math.exp(
                (snr_th[spreading[i] - 7]) * (sum1_9) / tp_0[i] /
                           a_gw1[i]))
            pdr_gw2.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum2_9) / tp_0[i] / a_gw2[i]))
            pdr_gw3.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum3_9) / tp_0[i] / a_gw3[i]))
        elif spreading[i] == 10:
            pdr_gw1.append(math.exp(
                (snr_th[spreading[i] - 7]) * (sum1_10 ) / tp_0[i] /
                           a_gw1[i]))
            pdr_gw2.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum2_10 ) / tp_0[i] / a_gw2[i]))
            pdr_gw3.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum3_10) / tp_0[i] / a_gw3[i]))
        elif spreading[i] == 11:
            pdr_gw1.append(math.exp(
                (snr_th[spreading[i] - 7]) * (sum1_11) / tp_0[i] /
                           a_gw1[i]))
            pdr_gw2.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum2_11 ) / tp_0[i] / a_gw2[i]))
            pdr_gw3.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum3_11 ) / tp_0[i]/ a_gw3[i]))
        elif spreading[i] == 12:
            pdr_gw1.append(math.exp(
                (snr_th[spreading[i] - 7]) * (sum1_12 ) / tp_0[i] /
                           a_gw1[i]))
            pdr_gw2.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum2_12 ) / tp_0[i] / a_gw2[i]))
            pdr_gw3.append(math.exp((snr_th[spreading[i] - 7]) * (
                    sum3_12 ) / tp_0[i] / a_gw3[i]))

for i in range(nodes):
    if 1.1e-300<pdr_gw1[i] < 0.01:
        num1 = len(str(int(1/pdr_gw1[i])))-1
        pdr_gw1[i] = pdr_gw1[i] * math.pow(10, num1)
    if 1.1e-300<pdr_gw2[i] < 0.01:
        num2 = len(str(int(1/pdr_gw2[i])))-1
        pdr_gw2[i] = pdr_gw2[i] * math.pow(10, num2)
    if 1.1e-300<pdr_gw3[i] < 0.01:
        num3 = len(str(int(1/pdr_gw3[i])))-1
        pdr_gw3[i] = pdr_gw3[i] * math.pow(10, num3)
    elif pdr_gw1[i] > 1:
        num1 = len(str(int(pdr_gw1[i])))
        pdr_gw1[i] = pdr_gw1[i] / math.pow(10, num1)
    elif pdr_gw2[i] > 1:
        num2 = len(str(int(pdr_gw2[i])))
        pdr_gw2[i] = pdr_gw2[i] / math.pow(10, num2)
    elif pdr_gw3[i] > 1:
        num3 = len(str(int(pdr_gw3[i])))
        pdr_gw3[i] = pdr_gw3[i] / math.pow(10, num3)
    elif pdr_gw1[i] == 0.0:
        pdr_gw1[i] = 0.05#random.random()
    elif pdr_gw2[i] == 0.0:
        pdr_gw2[i] = 0.05#random.random()
    elif pdr_gw3[i] == 0.0:
        pdr_gw3[i] = 0.05#random.random()
# print "pdr_gw1:" + str(pdr_gw1)
# print "pdr_gw2:" + str(pdr_gw2)
# print "pdr_gw3:" + str(pdr_gw3)
prr = []
for i in range(nodes):
    prr.append(1-(1-pdr_gw1[i])*(1-pdr_gw2[i])*(1-pdr_gw3[i]))
# calculate energy (mW)
energy = []
for i in range(nodes):
    sf_def = spreading[i]
    t = (20.25 + (8 * 25 - 4 * sf_def + 44) / (4 * sf_def)) * pow(2, sf_def) / 125000 *1000
    energy.append((tp_0[i]/60.0+23.0/30.0) * t)
ee = []
for i in range(nodes):
    ee.append(80*prr[i]/energy[i])
print "minee:" + str(min(ee)*10)