Codes for ICDCS'2019 simulation

#ALGORITHM
Used for generating the resource allocation of three different works: EF-LoRa, RS-LoRa and Legacy-LoRa.

Output: three lists as SF=[7,8,9,8,10,....], TP=[6,8,4,14,10,...], CH=[2,1,0,6,3,...]

#LORAWAN
NS-3 simulator for lorawan.

#Usage
1. First run the python files in "algorithm". 
2. Input the obtained allocation into NS-3 simulator \lorawan\examples\lorawan-tracing.cc
3. Output file "Calculate.txt" including information such as packet reception ratio.
4. For different deployment, the number of gateways and end-devices should be changed in both "algorithm" and simulator.