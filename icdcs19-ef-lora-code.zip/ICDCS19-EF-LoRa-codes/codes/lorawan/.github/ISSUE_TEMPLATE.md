## Expected Behavior


## Actual Behavior


## Steps to Reproduce the Problem

  1.
  2.
  3.

## Specifications

  - ns-3 version:
  - lorawan module version:
  - Platform:
  - Compiler:
